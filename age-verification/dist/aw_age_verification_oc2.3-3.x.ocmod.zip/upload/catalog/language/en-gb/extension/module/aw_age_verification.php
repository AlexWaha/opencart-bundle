<?php

// Age Verification Text
$_['text_age_title'] = 'Are you 18 years old?';
$_['text_age_message'] = 'This online store contains products for adults. To continue, please confirm your age.';
$_['button_age_confirm'] = 'Yes, I am 18 years old';
$_['button_age_decline'] = 'No, I am not 18 years old';
