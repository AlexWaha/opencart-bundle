<?php

if (isset($_GET['debug'])) {
    if ($_GET['debug'] == 1) {
        ini_set('display_errors', 1);
        ini_set('error_reporting', 32767);
    } else {
        ini_set('display_errors', 0);
    }
}
class ControllerExtensionModuleMsIntegration extends Controller
{
    public const MODE_LINK_ONLY = 0;

    public const MODE_LINK_CREATE = 1;

    public const MODE_LINK_CREATE_UPDATE = 2;

    public const MODE_UPDATE_ONLY = 3;

    public const UPDATE_MODE_BY_TIME = 0;

    public const UPDATE_MODE_ALL = 1;

    // Rewrite sendOrder method by AlexWaha.com
    // Unblock next events in the Opencart events list
    public function sendOrder(&$route, &$args)
    {

        if ($this->config->get('ms_integration_status')) {
            [$order_id, $order_status_id] = $args;
            if ($order_status_id !== 0) {

                $this->load->model('checkout/order');
                $order = $this->model_checkout_order->getOrder($order_id);

                if ($order && $order['order_status_id'] == 0) {
                    $this->load->library('moysklad');
                    if ($this->moysklad->checkLicence()['licence']) {
                        $this->moysklad->sendOrder($order);
                    }
                }
            }
        }
    }

    public function updateOrder()
    {
        if ($this->config->get('ms_integration_status')) {
            $this->load->library('moysklad');

            if ($this->moysklad->checkLicence()['licence']) {
                $this->moysklad->orders(self::MODE_UPDATE_ONLY);
            }
        }
    }

    public function updateProducts()
    {
        error_reporting(1 | 4);
        $this->load->library('moysklad');
        if (! $this->config->get('ms_integration_status')) {
            return false;
        }
        if ($this->moysklad->checkLicence()['licence']) {
            $this->moysklad->categories(self::MODE_LINK_CREATE_UPDATE);
            $this->moysklad->products(self::MODE_LINK_CREATE_UPDATE);
            $this->moysklad->variants(self::MODE_LINK_CREATE_UPDATE);
        }
        exit;
    }

    public function updateStock()
    {
        error_reporting(1 | 4);
        if (! $this->config->get('ms_integration_status')) {
            return false;
        }
        $this->load->library('moysklad');
        if ($this->moysklad->checkLicence()['licence']) {
            $this->moysklad->stock();
        }
        exit;
    }

    public function updateMsOrder()
    {
        error_reporting(1 | 4);
        if (! $this->config->get('ms_integration_status')) {
            return false;
        }
        $this->load->library('moysklad');
        if ($this->moysklad->checkLicence()['licence']) {
            $this->moysklad->updateStates();
        }
        exit;
    }
}
