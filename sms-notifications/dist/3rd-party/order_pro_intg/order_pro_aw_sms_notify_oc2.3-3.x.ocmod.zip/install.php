<?php
        $query_rm = "DELETE FROM `" . DB_PREFIX . "event` WHERE `code` = 'aw_sms_notify_orderproh'";
        $this->db->query($query_rm);

        $query = "INSERT INTO `" . DB_PREFIX . "event` SET `code` = 'aw_sms_notify_orderproh', `trigger` = 'admin/model/sale/orderproh/addOrderHistory/after', `action` = 'extension/module/aw_sms_event/orderEvent', `status` = '1'";
        $this->db->query($query);
?>
