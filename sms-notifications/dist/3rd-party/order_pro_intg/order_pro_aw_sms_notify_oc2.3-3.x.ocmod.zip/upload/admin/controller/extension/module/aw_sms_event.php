<?php
class ControllerExtensionModuleAwSmsEvent extends Controller {
	public function orderEvent(&$route, &$args) {
		if (isset($args[0])) {
			$order_id = $args[0];
		} else {
			$order_id = 0;
		}

		if (isset($args[1]) && $args[1]) {
			$order_status_id = $args[1]['order_status_id'];
			$comment = $args[1]['comment'];
			$admin_order = isset($args[1]['admin_order']) ? $args[1]['admin_order'] : 0;
			if(isset($args[1]['sendsms'])) {
				$sendsms = $args[1]['sendsms'];
			}else{
				$sendsms = 0;
			}
		} else {
			$order_status_id = 0;
			$comment = '';
			$admin_order = 0;
			$sendsms = 0;
		}

		$this->load->model('extension/module/aw_sms_event');
		$this->load->model('sale/order');

		// We need to grab the old order status ID
		$order_info = $this->model_sale_order->getOrder($order_id);

		if ($order_info) {
            // Send SMS for Order Status
            if($order_status_id && $admin_order && $sendsms) {
                $this->model_extension_module_aw_sms_event->sendOrderStatusSms($order_id, $order_status_id, $comment, $sendsms);
            }elseif($order_status_id && !$admin_order && $this->config->get('sms_notify_force')){
                $this->model_extension_module_aw_sms_event->sendOrderStatusSms($order_info['order_id'], $order_status_id, $comment, true);
            }
		}
	}
}