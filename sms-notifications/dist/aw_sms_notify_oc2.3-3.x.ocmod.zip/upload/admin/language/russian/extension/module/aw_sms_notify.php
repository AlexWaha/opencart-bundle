<?php

/**
 * @author  Alexander Vakhovski (AlexWaha)
 *
 * @link    https://alexwaha.com
 *
 * @email   support@alexwaha.com
 *
 * @license GPLv3
 */

include DIR_LANGUAGE . 'ru-ru/extension/module/aw_sms_notify.php';
