(function ($) {
  const methods = {
    init: function (options) {
      return this.each(function () {
        const $this = $(this);
        const data = $this.data('autocompleteAddress');

        if (!data) {
          $this.timer = null;
          $this.items = [];

          $.extend($this, options);

          $this.attr('autocomplete', 'off');

          $this.on('focus.autocompleteAddress', function () {
            $this.request('');
          });

          $this.on('blur.autocompleteAddress', function () {
            setTimeout(function (object) {
              object.hide();
            }, 200, $this);
          });

          $this.on('keydown.autocompleteAddress', function (event) {
            switch (event.keyCode) {
              case 27:
                $this.hide();
                break;
              default:
                $this.request();
                break;
            }
          });

          $this.click = function (event) {
            event.preventDefault();

            let value = $(event.target).parent().attr('data-value');

            if (value && $this.items[value]) {
              $this.select($this.items[value]);
            }
          };

          $this.show = function () {
            let pos = $this.position();

            $this.siblings('ul.' + $this.class).css({
              'top': pos.top + $this.outerHeight(),
              'left': pos.left,
            });

            $this.siblings('ul.' + $this.class).show();
          };

          $this.hide = function () {
            $this.siblings('ul.' + $this.class).hide();
          };

          $this.request = function (search) {
            clearTimeout($this.timer);

            $this.timer = setTimeout(function (object) {
              search = (typeof (search) === 'undefined') ? object.val() : search;

              object.source(search, $.proxy(object.response, object));
            }, 200, $this);
          };

          $this.response = function (json) {
            let html = '';

            if (json.length) {
              for (let i = 0; i < json.length; i++) {
                this.items[json[i]['value']] = json[i];

                html += '<li data-value="' + json[i]['value'] + '"><a href="#">' + json[i]['label'] + '</a></li>';
              }
            }

            if (html && $this.is(':focus')) {
              $this.show();
            } else {
              $this.hide();
            }

            $this.siblings('ul.' + $this.class).html(html);
          };

          $this.after('<ul class="' + $this.class + '"></ul>');
          $this.siblings('ul.' + $this.class).delegate('a', 'click', $.proxy($this.click, $this));
          $this.data('autocompleteAddress', true);
        }
      });
    },
    destroy: function () {
      return this.each(function () {
        const $this = $(this);

        $this.removeData('autocompleteAddress');

        $this.off('.autocompleteAddress');
      });
    },
  };

  $.fn.autocompleteAddress = function (method) {
    if (methods[method]) {
      return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
    } else if (typeof (method) === 'object' || !method) {
      return methods.init.apply(this, arguments);
    } else {
      $.error('Method "' + method + '" does not exist for jQuery.autocompleteAddress');
    }
  };
})(window.jQuery);

function ShippingData () {
  const self = this;
  let src, method, lang, city;
  let address1, citySelected, oldSelCity;

  self.methodsCity = [
    'novaposhta.department',
    'novaposhta.doors',
    'novaposhta.poshtomat',
    'rozetka_delivery.department',
    'ukrposhta.express_department',
    'ukrposhta.standard_department',
    'ukrposhta.express_doors',
    'ukrposhta.standard_doors',
    'justin.department',
  ];

  self.methodsDepartment = [
    'novaposhta.department',
    'novaposhta.poshtomat',
    'rozetka_delivery.department',
    'ukrposhta.express_department',
    'ukrposhta.standard_department',
    'justin.department',
  ];

  self.methodsAddress = [
    'novaposhta.doors',
  ];

  self.setProp = function () {
    self.method = $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
    self.address1 = $('select[data-type=select2][name*="address_1"]:visible').length;
    self.citySelected = $('[name*="city"]:visible').val();
    self.lang = $('html').attr('lang') || 'uk';
  };

  self.handlerChanges = function (name, value) {

    if ($.inArray(self.method, self.methodsCity.concat(self.methodsDepartment, self.methodsAddress)) !== -1) {
      self.address1 = $('select[data-type=select2][name*="address_1"]:visible').length;
      self.oldSelCity = citySelected;
      self.citySelected = $('[name*="city"]:visible').val() || self.oldSelCity;

      if (name.match(/zone/i)) {
        $('input[name*="city"]:visible').val('');
        $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible, input[name*="postcode"]:visible').val('');

        $('select[data-type=select2][name*="city"]:visible option').filter(':not(:eq(0))').remove();
        $('select[data-type=select2][name*="address_1"]:visible option').filter(':not(:eq(0))').remove();

      } else if (name.match(/city/i)) {
        $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible, input[name*="postcode"]:visible').val('');
        $('select[data-type=select2][name*="address_1"]:visible option').filter(':not(:eq(0))').remove();
        if (self.address1 && $.inArray(self.method, self.methodsDepartment) !== -1) {
          self.initSelect2Addres1();
        }
      } else if (name.match(/shipping_method/i)) {
        $('input[name*="city"]:visible').val('').autocompleteAddress('destroy');
        $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible, input[name*="postcode"]:visible').val('').autocompleteAddress('destroy');

        self.method = value;
      }
    } else if ($.inArray(value, self.methodsCity.concat(self.methodsDepartment, self.methodsAddress)) !== -1) {
      if (name.match(/shipping_method/i)) {
        $('input[name*="city"]:visible').val('');
        $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('');

        self.method = value;
      }
    }
  };

  self.getAddress = function (element, search) {
    let filter, action;

    if (element[0].name.match(/city/i)) {
      action = 'getCities';
      filter = $('[name*="zone"]:visible').val() || '';
    } else if (element[0].name.match(/address_1/i)) {
      action = 'getDepartments';
      filter = $('[name*="city"]:visible').val();
    } else if (element[0].name.match(/address_2|street/i)) {
      action = 'getStreets';
      filter = self.city || $('[name*="city"]:visible').val();
    } else if (element[0].name.match(/postcode/i)) {
      action = 'getPostCodes';
      filter = '';
    }

    if (!search) {
      search = element[0].value;
    }

    return $.ajax({
      url: 'index.php?route=extension/module/shippingdata/getShippingData',
      type: 'POST',
      data: 'shipping=' + self.method + '&action=' + action + '&filter=' + encodeURIComponent(filter) + '&search=' +
        encodeURIComponent(search),
      dataType: 'json',
      global: false,
      success: function (json) {
        self.src = json;
      },
    });
  };

  self.Select2Address = function (element, search) {
    let filter, action;

    if (element[0].name.match(/city/i)) {
      action = 'getCities';
      filter = $('[name*="zone"]:visible').val() || '';
    } else if (element[0].name.match(/address_1/i)) {
      action = 'getDepartments';
      filter = $('[name*="city"]:visible').val();
    } else if (element[0].name.match(/address_2|street/i)) {
      action = 'getStreets';
      filter = self.citySelected || $('[name*="city"]:visible').val();
    }

    if (!search) {
      search = '';
    }

    return $.ajax({
      url: 'index.php?route=extension/module/shippingdata/getShippingData',
      type: 'POST',
      data: 'shipping=' + self.method + '&action=' + action + '&filter=' + encodeURIComponent(filter) + '&search=' +
        encodeURIComponent(search),
      dataType: 'json',
      global: false,
    });
  };

  self.initSelect2Cities = function () {
    let select2Cities = $('select[data-type=select2][name*="city"]:visible'), items;

    if (!select2Cities.length) {
      if (self.address1 && $.inArray(self.method, self.methodsDepartment) !== -1) {
        self.initSelect2Addres1();
      }
    } else {
      self.Select2Address(select2Cities).done(function (results) {
        items = $.map(results, function (item) {
          return {
            id: item['description'],
            text: item['description'],
            selected: item['description'] === self.citySelected,
          };
        });
        select2Cities.select2({
          data: items,
          cache: false,
          ajax: {
            delay: 250,
            transport: function (params, success, failure) {
              self.Select2Address(select2Cities, params.data.term).done(function (results) {
                success({
                  results: $.map(results, function (item) {
                    return {
                      id: item['description'],
                      text: item['description'],
                    };
                  }),
                });
              }).fail(failure);
            },
            processResults: function (data) {
              return {
                results: data.results,
              };
            },
          },
          sorter: function (results) {
            const query = $('.select2-search__field').val().toLowerCase();
            return results.sort(function (a, b) {
              return a.text.toLowerCase().indexOf(query) - b.text.toLowerCase().indexOf(query);
            });
          },
        });
      }).done(function () {
        $('select[data-type=select2][name*="address_1"]:visible option').filter(':not(:eq(0))').remove();
        if (self.address1 && $.inArray(self.method, self.methodsDepartment) !== -1) {
          self.initSelect2Addres1();
        }
      });
    }
  };

  self.initSelect2Addres1 = function () {
    let select2Address1 = $('select[data-type=select2][name*="address_1"]:visible'), items;
    $('select[data-type=select2][name*="address_1"]:visible option').filter(':not(:eq(0))').remove();
    self.Select2Address(select2Address1).done(function (results) {
      items = $.map(results, function (item) {
        return {
          id: item['description'],
          text: item['description'],
        };
      });
      select2Address1.select2({
        data: items,
        cache: false,
        sorter: function (results) {
          const query = $('.select2-search__field').val().toLowerCase();
          return results.sort(function (a, b) {
            return a.text.toLowerCase().indexOf(query) - b.text.toLowerCase().indexOf(query);
          });
        },
      });
    });
  };
}

$(function () {
  const shippingData = new ShippingData();
  let $body = $('body');

  shippingData.setProp();

  $(document).ajaxStop(function () {
    shippingData.setProp();
  });

  $(document).on('change', '[name*="zone"]:visible, [name*="city"]:visible, [name*="shipping_method"]', function (e) {
    shippingData.handlerChanges(e.target.name, e.target.value);
  });

  $(document).ajaxComplete(function (event, xhr, settings) {
    if (settings.url === 'index.php?route=checkout/aw_easy_checkout/reload') {
      if (shippingData.method === 'novaposhta.doors') {
        $('input[name*="city"]:visible').val('');
        $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('');
      }
      setTimeout(function () {
        shippingData.initSelect2Cities();
      }, 500);
    }
  });

  if ($.inArray(shippingData.method, shippingData.methodsCity) !== -1) {
    if (shippingData.method === 'novaposhta.doors') {
      $('input[name*="city"]:visible').val('');
      $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('');
    }
    shippingData.initSelect2Cities();
  }

  $body.on('focus', 'input[name*="city"]:visible', function () {
    if (this.name.match(/city/i) && $.inArray(shippingData.method, shippingData.methodsCity) !== -1) {
      $(this).autocompleteAddress({
        source: function (request, response) {
          shippingData.getAddress(this, request).done(function () {
            response($.map(shippingData.src, function (item) {
              return {
                id: item['id'] || '',
                label: item['full_description'] || item['description'],
                value: item['description'],
              };
            }));
          });
        },
        select: function (e) {
          if (e.value !== this.val()) {
            this.val(e.value);
            shippingData.city = e.id;

            this.trigger('change');

          }
        },
        class: 'dropdown-address',
      });
    }
  });

  $body.on('focus', 'input[name*="address_1"]:visible', function () {
    if (this.name.match(/address_1/i) && $.inArray(shippingData.method, shippingData.methodsDepartment) !== -1) {
      $(this).autocompleteAddress({
        source: function (request, response) {
          shippingData.getAddress(this, request).done(function () {
            response($.map(shippingData.src, function (item) {
              return {
                label: item['full_description'] || item['description'],
                value: item['description'],
                postcode: item['postcode'] || '',
              };
            }));
          });
        },
        select: function (e) {
          if (e.value !== this.val()) {
            if (e.postcode) {
              $('input[name*="postcode"]:visible').val(e.postcode);
            }

            this.val(e.value);

            this.trigger('change');
          }
        },
        class: 'dropdown-address',
      });
    }
  });

  $body.on('focus', 'input[name*="address_2"]:visible, input[name*="street"]:visible', function () {
    if (this.name.match(/address_2|street/i) && $.inArray(shippingData.method, shippingData.methodsAddress) !== -1) {
      $(this).autocompleteAddress({
        source: function (request, response) {
          shippingData.getAddress(this, request).done(function () {
            response($.map(shippingData.src, function (item) {
              return {
                label: item['full_description'] || item['description'],
                value: item['description'],
              };
            }));
          });
        },
        select: function (e) {
          if (e.value !== this.val()) {
            this.val(e.value);

            this.trigger('change');
          }
        },
        class: 'dropdown-address',
      });
    }
  });

  $body.on('focus', 'input[name*="postcode"]:visible', function () {
    if (this.name.match(/postcode/i) && $.inArray(shippingData.method, shippingData.methodsCity) !== -1) {
      $(this).autocompleteAddress({
        source: function (request, response) {
          shippingData.getAddress(this, request).done(function () {
            response($.map(shippingData.src, function (item) {
              return {
                label: item['full_description'] || item['description'],
                value: item['description'],
                city: item['city'] || '',
                department: item['department'] || '',
              };
            }));
          });
        },
        select: function (e) {
          if (e.value !== this.val()) {
            if (e.city) {
              $('input[name*="city"]:visible').val(e.city);
            }

            if (e.department) {
              $('input[name*="address_1"]:visible').val(e.department);
            }

            this.val(e.value);

            this.trigger('change');
          }
        },
        class: 'dropdown-address',
      });
    }
  });
});
